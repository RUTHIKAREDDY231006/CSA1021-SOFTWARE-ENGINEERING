import { useMemo, useState } from "react";

type IconName =
  | "arrow"
  | "bag"
  | "chevron"
  | "heart"
  | "home"
  | "minus"
  | "plus"
  | "search"
  | "shop"
  | "user"
  | "x";

const paths: Record<IconName, React.ReactNode> = {
  arrow: <path d="m15 18-6-6 6-6" />,
  bag: <><path d="M6 8h12l1 12H5L6 8Z" /><path d="M9 9V6a3 3 0 0 1 6 0v3" /></>,
  chevron: <path d="m9 18 6-6-6-6" />,
  heart: <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1.1L12 21l7.8-7.5 1.1-1.1a5.5 5.5 0 0 0-.1-7.8Z" />,
  home: <><path d="m3 11 9-8 9 8" /><path d="M5 10v10h14V10M9 20v-6h6v6" /></>,
  minus: <path d="M5 12h14" />,
  plus: <><path d="M12 5v14" /><path d="M5 12h14" /></>,
  search: <><circle cx="11" cy="11" r="7" /><path d="m20 20-4-4" /></>,
  shop: <><path d="M4 9h16l-1 11H5L4 9Z" /><path d="m3 9 2-5h14l2 5M9 4v5m6-5v5" /></>,
  user: <><circle cx="12" cy="8" r="4" /><path d="M4 21a8 8 0 0 1 16 0" /></>,
  x: <><path d="m6 6 12 12" /><path d="M18 6 6 18" /></>,
};

function Icon({ name, filled = false, size = 20 }: { name: IconName; filled?: boolean; size?: number }) {
  return (
    <svg
      aria-hidden="true"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill={filled ? "currentColor" : "none"}
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {paths[name]}
    </svg>
  );
}

const products = [
  {
    id: 1,
    name: "The Column Dress",
    category: "New season",
    price: 168,
    image: "https://images.unsplash.com/photo-1659522761084-79196b64abe4?auto=format&fit=crop&w=900&q=85",
    color: "Oyster",
  },
  {
    id: 2,
    name: "Arc Shoulder Bag",
    category: "Accessories",
    price: 124,
    image: "https://images.unsplash.com/photo-1575202332411-b01fe9ace7a8?auto=format&fit=crop&w=900&q=85",
    color: "Stone",
  },
  {
    id: 3,
    name: "The Line Coat",
    category: "Outerwear",
    price: 245,
    image: "https://images.unsplash.com/photo-1762605135012-56a59a059e60?auto=format&fit=crop&w=900&q=85",
    color: "Camel",
  },
  {
    id: 4,
    name: "Soft Structure Bag",
    category: "Accessories",
    price: 138,
    image: "https://images.unsplash.com/photo-1604176424472-17cd740f74e9?auto=format&fit=crop&w=900&q=85",
    color: "Ivory",
  },
];

const categories = ["New in", "Clothing", "Bags", "Shoes", "Objects"];

export default function App() {
  const [activeTab, setActiveTab] = useState("Home");
  const [selectedProduct, setSelectedProduct] = useState<(typeof products)[number] | null>(null);
  const [wishlist, setWishlist] = useState<number[]>([2]);
  const [bagCount, setBagCount] = useState(0);
  const [bagOpen, setBagOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [activeCategory, setActiveCategory] = useState("New in");
  const [selectedSize, setSelectedSize] = useState("M");
  const [notice, setNotice] = useState("");

  const visibleProducts = useMemo(() => {
    if (activeTab === "Saved") return products.filter((product) => wishlist.includes(product.id));
    return products;
  }, [activeTab, wishlist]);

  function toggleSaved(id: number) {
    setWishlist((current) =>
      current.includes(id) ? current.filter((item) => item !== id) : [...current, id],
    );
  }

  function addToBag() {
    setBagCount((count) => count + 1);
    setNotice("Added to your bag");
    window.setTimeout(() => setNotice(""), 1800);
  }

  function changeTab(tab: string) {
    setActiveTab(tab);
    setSelectedProduct(null);
    if (tab === "Bag") setBagOpen(true);
  }

  return (
    <main className="app-shell">
      <section className="phone-frame" aria-label="Maison mobile shopping prototype">
        <div className="status-bar" aria-hidden="true">
          <span>9:41</span>
          <span className="status-icons">● ◒ ▰</span>
        </div>

        <header className="topbar">
          <button
            className="icon-button"
            onClick={() => setSearchOpen((open) => !open)}
            aria-label="Search"
          >
            <Icon name={searchOpen ? "x" : "search"} />
          </button>
          <button className="wordmark" onClick={() => changeTab("Home")} aria-label="Maison home">
            MAISON
          </button>
          <button className="icon-button bag-button" onClick={() => setBagOpen(true)} aria-label="Open bag">
            <Icon name="bag" />
            {bagCount > 0 && <span className="bag-count">{bagCount}</span>}
          </button>
        </header>

        {searchOpen && (
          <div className="search-panel">
            <Icon name="search" size={18} />
            <input autoFocus aria-label="Search products" placeholder="Search the collection" />
          </div>
        )}

        <div className="screen-content">
          {activeTab === "Home" && !selectedProduct && (
            <>
              <section className="hero">
                <img
                  src="https://images.unsplash.com/photo-1743751747067-49d618650353?auto=format&fit=crop&w=1100&q=85"
                  alt="Two models wearing neutral-toned pieces from the new collection"
                />
                <div className="hero-overlay" />
                <div className="hero-copy">
                  <p>Spring / Summer 2026</p>
                  <h1>Quiet forms,<br />bold presence.</h1>
                  <button onClick={() => document.getElementById("collection")?.scrollIntoView({ behavior: "smooth" })}>
                    Explore collection <span>↗</span>
                  </button>
                </div>
              </section>

              <nav className="category-scroll" aria-label="Product categories">
                {categories.map((category) => (
                  <button
                    key={category}
                    className={activeCategory === category ? "active" : ""}
                    onClick={() => setActiveCategory(category)}
                  >
                    {category}
                  </button>
                ))}
              </nav>

              <section className="collection-section" id="collection">
                <div className="section-heading">
                  <div>
                    <p>Curated for you</p>
                    <h2>{activeCategory}</h2>
                  </div>
                  <button>View all <Icon name="chevron" size={15} /></button>
                </div>
                <ProductGrid products={visibleProducts} wishlist={wishlist} onSave={toggleSaved} onOpen={setSelectedProduct} />
              </section>

              <section className="journal-card">
                <div>
                  <span>The journal · No. 08</span>
                  <h2>Objects of<br />lasting value</h2>
                  <button>Read the story <Icon name="chevron" size={15} /></button>
                </div>
                <img src="https://images.unsplash.com/photo-1654254124839-851f6103d1f2?auto=format&fit=crop&w=700&q=85" alt="Editorial portrait from the Maison journal" />
              </section>
            </>
          )}

          {activeTab === "Shop" && !selectedProduct && (
            <section className="tab-page">
              <p className="eyebrow">The collection</p>
              <h1>Shop all</h1>
              <nav className="category-scroll shop-categories">
                {categories.map((category) => (
                  <button key={category} className={activeCategory === category ? "active" : ""} onClick={() => setActiveCategory(category)}>{category}</button>
                ))}
              </nav>
              <ProductGrid products={products} wishlist={wishlist} onSave={toggleSaved} onOpen={setSelectedProduct} />
            </section>
          )}

          {activeTab === "Saved" && !selectedProduct && (
            <section className="tab-page">
              <p className="eyebrow">Your edit</p>
              <h1>Saved pieces</h1>
              {visibleProducts.length ? (
                <ProductGrid products={visibleProducts} wishlist={wishlist} onSave={toggleSaved} onOpen={setSelectedProduct} />
              ) : (
                <div className="empty-state"><Icon name="heart" size={28} /><p>No saved pieces yet.</p></div>
              )}
            </section>
          )}

          {activeTab === "Profile" && !selectedProduct && (
            <section className="tab-page account-page">
              <div className="profile-mark"><Icon name="user" size={28} /></div>
              <p className="eyebrow">Welcome to Maison</p>
              <h1>Your account</h1>
              <p>Sign in to track orders, save your edit and enjoy a more personal experience.</p>
              <button className="primary-button">Sign in</button>
              {["Orders & returns", "Personal details", "Delivery addresses", "Help & contact"].map((item) => (
                <button className="account-link" key={item}>{item}<Icon name="chevron" size={17} /></button>
              ))}
            </section>
          )}

          {selectedProduct && (
            <section className="product-detail">
              <div className="product-visual">
                <img src={selectedProduct.image} alt={selectedProduct.name} />
                <button className="back-button" onClick={() => setSelectedProduct(null)} aria-label="Back to products"><Icon name="arrow" /></button>
                <button className="detail-heart" onClick={() => toggleSaved(selectedProduct.id)} aria-label="Save product">
                  <Icon name="heart" filled={wishlist.includes(selectedProduct.id)} />
                </button>
                <div className="image-count">1 / 3</div>
              </div>
              <div className="product-info">
                <p>{selectedProduct.category}</p>
                <div className="product-title-row">
                  <h1>{selectedProduct.name}</h1>
                  <span>${selectedProduct.price}</span>
                </div>
                <p className="product-description">An exercise in considered simplicity, designed with a precise silhouette and a softly structured finish.</p>
                <div className="option-row">
                  <span>Color</span><strong>{selectedProduct.color}</strong>
                </div>
                <div className="swatches"><button className="swatch selected" aria-label="Oyster" /><button className="swatch dark" aria-label="Black" /><button className="swatch sand" aria-label="Sand" /></div>
                <div className="option-row"><span>Select size</span><button className="size-guide">Size guide</button></div>
                <div className="size-grid">
                  {["XS", "S", "M", "L", "XL"].map((size) => <button key={size} className={selectedSize === size ? "selected" : ""} onClick={() => setSelectedSize(size)}>{size}</button>)}
                </div>
                <button className="primary-button add-button" onClick={addToBag}>Add to bag <span>${selectedProduct.price}</span></button>
                <button className="detail-row">Details & care <Icon name="plus" size={18} /></button>
                <button className="detail-row">Delivery & returns <Icon name="plus" size={18} /></button>
              </div>
            </section>
          )}
        </div>

        <nav className="bottom-nav" aria-label="Main navigation">
          {[
            ["Home", "home"],
            ["Shop", "shop"],
            ["Saved", "heart"],
            ["Bag", "bag"],
            ["Profile", "user"],
          ].map(([label, icon]) => (
            <button key={label} className={activeTab === label ? "active" : ""} onClick={() => changeTab(label)}>
              <span className="nav-icon"><Icon name={icon as IconName} filled={label === "Saved" && activeTab === label} /></span>
              <span>{label}</span>
              {label === "Bag" && bagCount > 0 && <i>{bagCount}</i>}
            </button>
          ))}
        </nav>

        {bagOpen && (
          <div className="modal-layer" role="dialog" aria-modal="true" aria-label="Shopping bag">
            <button className="modal-scrim" onClick={() => { setBagOpen(false); setActiveTab("Home"); }} aria-label="Close bag" />
            <section className="bag-sheet">
              <div className="sheet-handle" />
              <div className="bag-heading">
                <div><p>Your bag</p><h2>{bagCount ? `${bagCount} item${bagCount > 1 ? "s" : ""}` : "Bag is empty"}</h2></div>
                <button className="icon-button" onClick={() => { setBagOpen(false); setActiveTab("Home"); }}><Icon name="x" /></button>
              </div>
              {bagCount > 0 ? (
                <>
                  <div className="bag-item">
                    <img src={selectedProduct?.image || products[0].image} alt="" />
                    <div><strong>{selectedProduct?.name || products[0].name}</strong><span>{selectedSize} · {selectedProduct?.color || "Oyster"}</span><span>${selectedProduct?.price || products[0].price}</span></div>
                    <div className="quantity"><button><Icon name="minus" size={14} /></button><span>{bagCount}</span><button onClick={() => setBagCount((count) => count + 1)}><Icon name="plus" size={14} /></button></div>
                  </div>
                  <div className="bag-total"><span>Subtotal</span><strong>${(selectedProduct?.price || products[0].price) * bagCount}</strong></div>
                  <p className="shipping-note">Complimentary delivery and returns</p>
                  <button className="primary-button">Continue to checkout</button>
                </>
              ) : (
                <div className="empty-bag"><Icon name="bag" size={30} /><p>Your considered edit starts here.</p><button className="primary-button" onClick={() => { setBagOpen(false); setActiveTab("Shop"); }}>Explore the collection</button></div>
              )}
            </section>
          </div>
        )}

        {notice && <div className="toast"><span>✓</span>{notice}</div>}
      </section>
      <aside className="prototype-note">
        <span>Interactive prototype</span>
        <h2>MAISON<br />Mobile commerce</h2>
        <p>Explore products, save favorites, select a size and add an item to the bag.</p>
        <div><i /> Ready for stakeholder review</div>
      </aside>
    </main>
  );
}

function ProductGrid({ products: items, wishlist, onSave, onOpen }: {
  products: typeof products;
  wishlist: number[];
  onSave: (id: number) => void;
  onOpen: (product: (typeof products)[number]) => void;
}) {
  return (
    <div className="product-grid">
      {items.map((product) => (
        <article className="product-card" key={product.id}>
          <div className="product-image">
            <button className="product-open" onClick={() => onOpen(product)} aria-label={`View ${product.name}`} />
            <img src={product.image} alt={product.name} />
            <button className="heart-button" onClick={() => onSave(product.id)} aria-label="Save product">
              <Icon name="heart" filled={wishlist.includes(product.id)} size={18} />
            </button>
          </div>
          <button className="product-meta" onClick={() => onOpen(product)}>
            <span>{product.category}</span>
            <strong>{product.name}</strong>
            <b>${product.price}</b>
          </button>
        </article>
      ))}
    </div>
  );
}
