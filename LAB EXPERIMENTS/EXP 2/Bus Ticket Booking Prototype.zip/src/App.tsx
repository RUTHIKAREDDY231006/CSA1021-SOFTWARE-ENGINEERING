import { useMemo, useState } from "react";

type IconName =
  | "arrow"
  | "bus"
  | "calendar"
  | "check"
  | "chevron"
  | "clock"
  | "location"
  | "route"
  | "search"
  | "seat"
  | "shield"
  | "swap"
  | "ticket"
  | "user";

function Icon({ name, size = 20 }: { name: IconName; size?: number }) {
  const paths: Record<IconName, React.ReactNode> = {
    arrow: <><path d="M5 12h14" /><path d="m14 7 5 5-5 5" /></>,
    bus: <><path d="M5 16V6.5A2.5 2.5 0 0 1 7.5 4h9A2.5 2.5 0 0 1 19 6.5V16" /><path d="M5 11h14M7 16h10M8 19v1m8-1v1M8 7h8" /><circle cx="8" cy="15" r=".5" fill="currentColor" /><circle cx="16" cy="15" r=".5" fill="currentColor" /></>,
    calendar: <><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M16 3v4M8 3v4M3 10h18" /></>,
    check: <path d="m5 12 4 4L19 6" />,
    chevron: <path d="m9 18 6-6-6-6" />,
    clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>,
    location: <><path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z" /><circle cx="12" cy="10" r="2.5" /></>,
    route: <><circle cx="6" cy="18" r="2" /><circle cx="18" cy="6" r="2" /><path d="M8 18h2a4 4 0 0 0 4-4v-4a4 4 0 0 1 4-4" /></>,
    search: <><circle cx="11" cy="11" r="7" /><path d="m20 20-4-4" /></>,
    seat: <><path d="M6 11V6a3 3 0 0 1 6 0v5M5 11h10a3 3 0 0 1 3 3v4H6a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2ZM7 18v2m9-2v2" /></>,
    shield: <><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z" /><path d="m9 12 2 2 4-5" /></>,
    swap: <><path d="m7 7 3-3 3 3M10 4v12" /><path d="m17 17-3 3-3-3M14 20V8" /></>,
    ticket: <><path d="M3 8a2 2 0 0 0 0 4v5h18v-5a2 2 0 0 0 0-4V3H3v5Z" /><path d="M13 6h4M13 10h4M8 6v8" /></>,
    user: <><circle cx="12" cy="8" r="4" /><path d="M4 21a8 8 0 0 1 16 0" /></>,
  };

  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      {paths[name]}
    </svg>
  );
}

const buses = [
  { id: 1, company: "Northline Express", type: "AC Sleeper · 2+1", depart: "21:30", arrive: "05:45", duration: "8h 15m", rating: "4.8", reviews: "1.2k", price: 32, seats: 12 },
  { id: 2, company: "Cityway Travels", type: "Premium Coach · 2+2", depart: "22:15", arrive: "06:50", duration: "8h 35m", rating: "4.6", reviews: "864", price: 27, seats: 8 },
  { id: 3, company: "Bluebird Transit", type: "AC Sleeper · 2+1", depart: "23:00", arrive: "07:10", duration: "8h 10m", rating: "4.7", reviews: "942", price: 35, seats: 15 },
];

const seatNumbers = ["1A", "1B", "1C", "2A", "2B", "2C", "3A", "3B", "3C", "4A", "4B", "4C"];
const occupiedSeats = ["1C", "2B", "4A"];

export default function App() {
  const [from, setFrom] = useState("New York");
  const [to, setTo] = useState("Washington, DC");
  const [date, setDate] = useState("Fri, 24 May");
  const [searched, setSearched] = useState(false);
  const [selectedBus, setSelectedBus] = useState<number | null>(null);
  const [selectedSeats, setSelectedSeats] = useState<string[]>([]);
  const [booked, setBooked] = useState(false);

  const bus = useMemo(() => buses.find((item) => item.id === selectedBus), [selectedBus]);

  const swapCities = () => {
    setFrom(to);
    setTo(from);
  };

  const toggleSeat = (seat: string) => {
    if (occupiedSeats.includes(seat)) return;
    setSelectedSeats((current) =>
      current.includes(seat) ? current.filter((item) => item !== seat) : current.length < 3 ? [...current, seat] : current,
    );
  };

  const selectBus = (id: number) => {
    setSelectedBus(id);
    setSelectedSeats([]);
    setBooked(false);
  };

  return (
    <main className="app-shell">
      <nav className="topbar">
        <button className="brand" onClick={() => setSearched(false)} aria-label="Go to home">
          <span className="brand-mark"><Icon name="route" size={22} /></span>
          <span>route<span className="brand-dot">.</span></span>
        </button>
        <div className="nav-links" aria-label="Main navigation">
          <button className="nav-link active">Book a trip</button>
          <button className="nav-link">My tickets</button>
          <button className="nav-link">Help</button>
        </div>
        <button className="account-button"><span className="account-avatar"><Icon name="user" size={17} /></span> Sign in</button>
      </nav>

      <section className="hero">
        <div className="hero-copy">
          <span className="eyebrow"><span className="eyebrow-line" /> GO PLACES, EASILY</span>
          <h1>Your next trip<br />starts <em>here.</em></h1>
          <p>Compare routes, choose your seat, and book your bus ticket in less than two minutes.</p>
          <div className="trust-row">
            <span><Icon name="shield" size={18} /> Secure booking</span>
            <span><Icon name="ticket" size={18} /> Instant e-ticket</span>
          </div>
        </div>

        <div className="booking-panel">
          <div className="booking-title">
            <div><span>Find your bus</span><small>Where would you like to go?</small></div>
            <span className="step-pill">01 — Search</span>
          </div>

          <div className="route-fields">
            <label className="field">
              <span className="field-label">FROM</span>
              <span className="field-control"><Icon name="location" size={19} /><input value={from} onChange={(event) => setFrom(event.target.value)} aria-label="Departure city" /></span>
            </label>
            <button className="swap-button" onClick={swapCities} aria-label="Swap departure and destination"><Icon name="swap" size={18} /></button>
            <label className="field">
              <span className="field-label">TO</span>
              <span className="field-control"><Icon name="location" size={19} /><input value={to} onChange={(event) => setTo(event.target.value)} aria-label="Destination city" /></span>
            </label>
          </div>

          <div className="date-section">
            <span className="field-label">DEPARTURE</span>
            <div className="date-options">
              {["Today, 22 May", "Tomorrow, 23 May", "Fri, 24 May"].map((item) => (
                <button key={item} className={`date-chip ${date === item ? "selected" : ""}`} onClick={() => setDate(item)}>
                  {item === "Fri, 24 May" && <Icon name="calendar" size={17} />}
                  {item}
                </button>
              ))}
            </div>
          </div>
          <button className="search-button" onClick={() => setSearched(true)}><Icon name="search" size={20} /> Search buses <Icon name="arrow" size={19} /></button>
        </div>
      </section>

      <section className={`results-section ${searched ? "highlight-results" : ""}`}>
        <div className="results-heading">
          <div>
            <span className="section-kicker">{searched ? "SEARCH RESULTS" : "POPULAR DEPARTURES"}</span>
            <h2>{from} <Icon name="arrow" size={21} /> {to}</h2>
            <p>{date} · {buses.length} buses found</p>
          </div>
          <button className="sort-button">Sort: Recommended <Icon name="chevron" size={16} /></button>
        </div>

        <div className="results-layout">
          <div className="bus-list">
            {buses.map((item, index) => (
              <article className={`bus-card ${selectedBus === item.id ? "selected-bus" : ""}`} key={item.id}>
                <div className="bus-accent"><span>0{index + 1}</span></div>
                <div className="bus-main">
                  <div className="operator">
                    <span className="bus-icon"><Icon name="bus" size={21} /></span>
                    <div><h3>{item.company}</h3><p>{item.type}</p></div>
                  </div>
                  <div className="time-block">
                    <strong>{item.depart}</strong>
                    <div className="journey-line"><span /><small>{item.duration}</small><span /></div>
                    <strong>{item.arrive}</strong>
                  </div>
                  <div className="rating"><span>★ {item.rating}</span><small>{item.reviews} reviews</small></div>
                  <div className="price"><small>From</small><strong>${item.price}</strong><span>{item.seats} seats left</span></div>
                  <button className="select-button" onClick={() => selectBus(item.id)}>{selectedBus === item.id ? "Selected" : "Select seats"}<Icon name="chevron" size={16} /></button>
                </div>
                <div className="amenities">
                  <span>Wi-Fi</span><span>Power outlet</span><span>Reclining seats</span><button>Trip details</button>
                </div>
              </article>
            ))}
          </div>

          <aside className={`seat-panel ${bus ? "open" : ""}`}>
            {!bus ? (
              <div className="empty-selection">
                <span className="empty-icon"><Icon name="seat" size={28} /></span>
                <h3>Choose your ride</h3>
                <p>Select a bus to view the seat map and continue your booking.</p>
                <div className="progress-steps"><span className="done" /><span /><span /></div>
              </div>
            ) : booked ? (
              <div className="success-state">
                <span className="success-icon"><Icon name="check" size={30} /></span>
                <span className="section-kicker">BOOKING CONFIRMED</span>
                <h3>You're ready to go.</h3>
                <p>Your e-ticket for {from} to {to} is ready.</p>
                <div className="ticket-code"><small>BOOKING ID</small><strong>RT–2847</strong></div>
                <button className="search-button" onClick={() => { setBooked(false); setSelectedBus(null); }}>View my ticket <Icon name="arrow" size={18} /></button>
              </div>
            ) : (
              <>
                <div className="seat-header">
                  <div><span className="section-kicker">CHOOSE YOUR SEAT</span><h3>{bus.company}</h3></div>
                  <button onClick={() => setSelectedBus(null)} aria-label="Close seat selection">×</button>
                </div>
                <div className="seat-legend"><span><i className="available" />Available</span><span><i className="chosen" />Selected</span><span><i className="unavailable" />Taken</span></div>
                <div className="coach">
                  <div className="driver"><span /><small>FRONT</small></div>
                  <div className="seat-grid">
                    {seatNumbers.map((seat, index) => (
                      <button
                        key={seat}
                        disabled={occupiedSeats.includes(seat)}
                        className={`${selectedSeats.includes(seat) ? "chosen" : ""} ${(index + 1) % 3 === 0 ? "aisle" : ""}`}
                        onClick={() => toggleSeat(seat)}
                      >{seat}</button>
                    ))}
                  </div>
                </div>
                <div className="fare-summary">
                  <div><span>{selectedSeats.length ? `${selectedSeats.length} seat${selectedSeats.length > 1 ? "s" : ""}` : "Select up to 3 seats"}</span><strong>{selectedSeats.length ? selectedSeats.join(", ") : "—"}</strong></div>
                  <div><span>Total</span><strong>${bus.price * selectedSeats.length}</strong></div>
                </div>
                <button className="search-button" disabled={!selectedSeats.length} onClick={() => setBooked(true)}>Continue to checkout <Icon name="arrow" size={18} /></button>
              </>
            )}
          </aside>
        </div>
      </section>

      <footer>
        <span>© 2025 route.</span>
        <div><span>2M+ happy travelers</span><span>240+ destinations</span><span>24/7 support</span></div>
      </footer>
    </main>
  );
}
